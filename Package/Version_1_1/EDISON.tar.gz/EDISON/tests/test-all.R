library(testthat)
test_check("EDISON")