library(testthat)
library(EDISON)

test_package('EDISON')